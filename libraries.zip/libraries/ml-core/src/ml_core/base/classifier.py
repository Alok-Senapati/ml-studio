from __future__ import annotations

from abc import abstractmethod

from ml_core.base.estimator import Estimator
from ml_core.typing import FloatArray, NumericArray


class Classifier(Estimator):
    """Base interface for all classifiers"""

    @abstractmethod
    def predict_proba(self, X: NumericArray) -> FloatArray:
        """Return prediction probabilities"""